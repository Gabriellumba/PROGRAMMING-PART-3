﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using WinFormsApp1.services;
using WinFormsApp1.Models;
using MySqlConnector;

namespace WinFormsApp1;

/// <summary>
/// The "brain" of the chatbot. The form calls GetResponse() every time the user sends a message and
/// shows whatever text comes back. Everything the bot has to remember between messages is kept in
/// fields of this class, because a GUI has no loop that keeps local variables alive.
///
/// Order of checks inside GetResponse (the order matters):
///   1. empty input   2. a question the bot asked earlier (name, reminder...)   3. information the user shares
///   4. commands (tasks, reminders, quiz, activity log)   5. sentiment   6. cybersecurity keywords
///   7. follow-ups ("tell me more")   8. small talk   9. fallback
/// </summary>
public class ChatEngine
{
    // ---- Step 2 of the guide: what the bot remembers between messages ----
    private string userName = "";
    private string favouriteTopic = "";     // what the user said they are interested in
    private string lastTopic = "";          // last topic discussed, used for follow-up questions
    private Random rng = new Random();

    // ---- Step 3: keyword -> list of possible replies (a list lets us pick a random one) ----
    private Dictionary<string, List<string>> keywordResponses = new Dictionary<string, List<string>>();
    private Dictionary<string, List<string>> topicKeywords = new Dictionary<string, List<string>>();
    private Dictionary<string, List<string>> topicDetails = new Dictionary<string, List<string>>();
    private Dictionary<string, string> topicNames = new Dictionary<string, string>();
    private Dictionary<string, string> topicNudges = new Dictionary<string, string>();
    private List<string> topicOrder = new List<string>();

    // ---- Step 4: mood words, kept separate from the topic keywords ----
    private Dictionary<string, List<string>> sentimentWords = new Dictionary<string, List<string>>();
    private Dictionary<string, List<string>> sentimentReplies = new Dictionary<string, List<string>>();

    // ---- greetings and other general questions ----
    private Dictionary<string, List<string>> smallTalk = new Dictionary<string, List<string>>();

    // ---- state of a conversation that is "in the middle" of something ----
    private string pendingStep = "";        // "", "name", "taskTitle", "reminderChoice", "reminderTime"
    private TaskItem pendingTask;           // the task we are asking the reminder question about
    private bool pendingIsReminder;         // true when the user started with "remind me..."
    private int retries;
    private int logShown;                   // how many activity-log lines were already shown
    private bool lastWasLog;
    private bool previousWasLog;
    private Dictionary<string, int> lastPicked = new Dictionary<string, int>();
    private List<int> notifiedTaskIds = new List<int>();

    /// <summary>Everything the bot does is written here (shared with the Activity Log tab).</summary>
    public ActivityLog Log { get; private set; }

    /// <summary>Task storage in MySQL (shared with the Task Assistant tab).</summary>
    public TaskManager Tasks { get; private set; }

    public bool DatabaseReady { get; private set; }
    public string DatabaseStatus { get; private set; }

    /// <summary>Set to true when the user asks for the quiz; the form opens the Quiz tab and resets it.</summary>
    public bool QuizRequested { get; set; }

    public ChatEngine()
    {
        Log = new ActivityLog();
        Tasks = new TaskManager(Log);

        string message;
        DatabaseReady = Tasks.Initialize(out message);
        DatabaseStatus = message;

        LoadTopics();
        LoadSentiment();
        LoadSmallTalk();
    }

    // =====================================================================================
    // Public methods used by the form
    // =====================================================================================

    /// <summary>The first message of the conversation: asks for the user's name.</summary>
    public string StartConversation()
    {
        pendingStep = "name";
        return "Hello! Welcome to the Cybersecurity Awareness Bot. I'm here to help you stay safe online. "
             + "Before we start, what is your name?";
    }

    /// <summary>Forgets the conversation (used by the Clear button).</summary>
    public void Reset()
    {
        userName = "";
        favouriteTopic = "";
        lastTopic = "";
        pendingStep = "";
        pendingTask = null;
        logShown = 0;
        lastPicked.Clear();
    }

    /// <summary>Tries to reach MySQL again if it was down at start-up. Returns true when it is ready.</summary>
    public bool EnsureDatabase()
    {
        if (!DatabaseReady)
        {
            string message;
            DatabaseReady = Tasks.Initialize(out message);
            DatabaseStatus = message;
        }
        return DatabaseReady;
    }

    /// <summary>
    /// The single entry point called by the Send button and the Enter key (Step 5 of the guide).
    /// It never throws: any problem becomes a friendly message instead of a crash.
    /// </summary>
    public string GetResponse(string input)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return "Please type something first, for example \"Give me a phishing tip\" or \"Add a task to enable 2FA\".";
            }

            input = input.Replace("\u2019", "'");           // curly apostrophe -> normal one
            string question = input.ToLower().Trim();

            previousWasLog = lastWasLog;
            lastWasLog = false;

            string reply = "";
            if (pendingStep != "") reply = HandlePendingStep(input, question);
            if (reply == "") reply = CaptureUserInfo(input, question);
            if (reply == "") reply = HandleCommands(input, question);
            if (reply == "") reply = HandleSentiment(question);
            if (reply == "") reply = HandleKeyword(question);
            if (reply == "") reply = HandleFollowUp(question);
            if (reply == "") reply = HandleSmallTalk(question);
            if (reply == "") reply = Fallback();

            return reply.Replace("{name}", NameForReply());
        }
        catch (MySqlConnector.MySqlException)
        {
            DatabaseReady = false;
            return "Sorry " + NameForReply() + ", I couldn't reach the task database. Please check that MySQL is running and try again.";
        }
        catch (Exception ex)
        {
            return "Sorry " + NameForReply() + ", something went wrong (" + ex.Message + "). Please try again.";
        }
    }

    /// <summary>Returns a message for every task whose reminder time has arrived (each one only once).</summary>
    public List<string> CheckReminders()
    {
        List<string> messages = new List<string>();
        if (!DatabaseReady) return messages;

        try
        {
            foreach (TaskItem t in Tasks.GetAllTasks())
            {
                bool due = !t.IsCompleted && t.ReminderDate.HasValue && t.ReminderDate.Value <= DateTime.Now;
                if (due && !notifiedTaskIds.Contains(t.Id))
                {
                    notifiedTaskIds.Add(t.Id);
                    Log.Add("Reminder due: '" + t.Title + "'");
                    messages.Add("Reminder: it's time to \"" + t.Title + "\". " + t.Description);
                }
            }
        }
        catch (Exception)
        {
            // The database may be busy; try again on the next timer tick.
        }
        return messages;
    }

    // =====================================================================================
    // Data (keywords, tips, moods, small talk)
    // =====================================================================================

    /// <summary>Adds one cybersecurity topic with its keywords, tips and extra explanations.</summary>
    private void AddTopic(string key, string displayName, string[] keywords, string[] tips, string[] details, string nudge)
    {
        topicOrder.Add(key);
        topicNames[key] = displayName;
        topicKeywords[key] = new List<string>(keywords);
        keywordResponses[key] = new List<string>(tips);
        topicDetails[key] = new List<string>(details);
        topicNudges[key] = nudge;
    }

    private void LoadTopics()
    {
        AddTopic("2fa", "two-factor authentication",
            new[] { "2fa", "two-factor", "two factor", "mfa", "authenticator", "otp", "one-time pin" },
            new[]
            {
                "Turn on two-factor authentication (2FA) for your email, banking and social media. A stolen password alone is then not enough.",
                "Prefer an authenticator app to SMS codes when you can - criminals can sometimes hijack a phone number (SIM swap).",
                "Never read a one-time PIN (OTP) out to anyone, not even someone who says they work for your bank."
            },
            new[]
            {
                "2FA asks for something you know (your password) and something you have (your phone or a security key). If criminals get the password they are still stopped at the second step.",
                "Keep your backup codes somewhere safe, but not in your email. They get you back in if you lose your phone."
            },
            "you might want to check which of your accounts still don't have 2FA switched on.");

        AddTopic("password", "password safety",
            new[] { "password", "passphrase", "passcode", "credentials" },
            new[]
            {
                "Make sure to use strong, unique passwords for each account. Avoid personal details like birthdays or pet names.",
                "Try a passphrase: four or more random words, for example 'purple-tractor-melon-cloud', are long, strong and easy to remember.",
                "A password manager remembers every password for you, so you only need one strong master password.",
                "If a website reports a data breach, change that password straight away - and anywhere else you used it."
            },
            new[]
            {
                "Criminals try passwords leaked from one website on many other websites. A different password for each account stops one breach from becoming many.",
                "Length beats complexity. A long passphrase is far harder to crack than a short password full of symbols."
            },
            "you could replace any old passwords that you use on more than one account.");

        AddTopic("phishing", "phishing",
            new[] { "phishing", "phish", "smishing", "vishing", "fake email", "suspicious email", "spam" },
            new[]
            {
                "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organisations like your bank or SARS.",
                "Check the sender's real email address and hover over a link before you click it. Look for small spelling changes in the web address.",
                "Messages that make you panic ('your account closes in 24 hours!') are a classic phishing trick. Slow down and check through the official app or website.",
                "Don't open attachments you weren't expecting - even from people you know. Their account may have been hacked."
            },
            new[]
            {
                "Phishing is not only email. It also arrives by SMS (smishing), phone call (vishing) and WhatsApp. The goal is always to rush you into giving away passwords, PINs or money.",
                "If you are unsure, contact the organisation on the number on its official website or the back of your card - never the number in the message."
            },
            "you could practise spotting phishing with the quiz in the Quiz tab.");

        AddTopic("scam", "online scams",
            new[] { "scam", "fraud", "con artist", "too good to be true", "sim swap" },
            new[]
            {
                "If an offer seems too good to be true, it almost always is. Never pay a 'fee' to receive a prize or a loan.",
                "Never send money or gift vouchers to someone you only know from the internet, however convincing the story.",
                "Be careful of a WhatsApp message from a 'family member' on a new number asking for urgent money. Call their old number first.",
                "Report scams to your bank straight away, and to SABRIC or the SAPS."
            },
            new[]
            {
                "Most scams add pressure: a time limit, secrecy or fear. Real organisations give you time to think and check.",
                "Common scams include fake job offers, online shopping fraud, romance scams and investments that promise guaranteed returns."
            },
            "you could tell your family and friends about scams you've seen so they stay alert too.");

        AddTopic("privacy", "privacy",
            new[] { "privacy", "personal information", "personal data", "popia", "tracking", "data protection" },
            new[]
            {
                "Privacy matters. Be careful how much personal information you share online - your ID number, address and birthday are valuable to criminals.",
                "Review the privacy settings on your social media accounts and limit who can see your posts and contact details.",
                "Check which apps can use your location, microphone and contacts, and switch off anything they don't need.",
                "Under POPIA you have rights over your personal information. You can ask organisations what they keep about you."
            },
            new[]
            {
                "Small details add up. A public post showing your school, birthday and pet's name can answer your security questions for an attacker.",
                "Use a separate email address for important accounts like banking and another for newsletters and sign-ups."
            },
            "you might want to review the security settings on your accounts.");

        AddTopic("browsing", "safe browsing",
            new[] { "browsing", "browser", "suspicious link", "link", "https", "website", "url", "download" },
            new[]
            {
                "Look for https:// and the padlock before typing personal details - but remember the padlock only means the connection is encrypted, not that the site is honest.",
                "Hover over a link to see where it really goes before you click, and type your bank's address yourself.",
                "Only download apps and programs from official app stores or the maker's own website.",
                "Keep your browser up to date and be suspicious of pop-ups that say your device is infected."
            },
            new[]
            {
                "Criminals register look-alike addresses such as 'bank-secure-login.com'. Read the part of the address just before the first single slash.",
                "Shortened links hide where they lead. If you don't trust the sender, don't click."
            },
            "you could check that your browser and its extensions are up to date.");

        AddTopic("malware", "malware",
            new[] { "malware", "virus", "ransomware", "trojan", "spyware", "antivirus" },
            new[]
            {
                "Use reputable antivirus software, keep it updated and run regular scans.",
                "Ransomware locks your files until you pay. Regular backups kept somewhere else are the best defence.",
                "Don't plug in unknown USB drives and don't install cracked software - both are common ways malware spreads."
            },
            new[]
            {
                "Malware is any software made to cause harm: viruses, trojans (disguised as useful programs), spyware (watches you) and ransomware (holds files hostage).",
                "If you think you are infected, disconnect from the internet, run a full scan and change your passwords from a clean device."
            },
            "you could check that your backups work and your antivirus is current.");

        AddTopic("wifi", "Wi-Fi security",
            new[] { "wifi", "wi-fi", "hotspot", "public network", "router", "vpn" },
            new[]
            {
                "Avoid banking or typing passwords on public Wi-Fi. Use mobile data or a trusted VPN instead.",
                "Change your home router's default admin password and use WPA2 or WPA3 encryption.",
                "Switch off auto-connect to open Wi-Fi on your phone. Attackers set up fake hotspots with familiar names."
            },
            new[]
            {
                "On an open network other people may be able to see unprotected traffic. A VPN encrypts the connection between your device and the VPN server.",
                "Keep your router's firmware updated. Old routers are a common way in for attackers."
            },
            "you could check your router's admin password and Wi-Fi encryption type.");

        AddTopic("social", "social engineering",
            new[] { "social engineering", "impersonat", "pretext", "manipulat", "fake call" },
            new[]
            {
                "Social engineering tricks people, not computers. If someone pressures you for information, hang up and check using official contact details.",
                "Be careful what you share on social media. Attackers use it to make their stories believable.",
                "Real support staff will never ask for your full PIN, password or OTP."
            },
            new[]
            {
                "Attackers use trust, fear, urgency and your wish to be helpful. Examples: a fake 'IT support' call, or a stranger following you through a secure door.",
                "A simple rule: check first, act second - and use a channel you trust, not the one the stranger gave you."
            },
            "you might want to agree on a 'safe word' with your family for urgent money requests.");

        AddTopic("backup", "backups and updates",
            new[] { "backup", "back up", "software update", "updates", "patch" },
            new[]
            {
                "Follow the 3-2-1 rule: three copies of your data, on two kinds of storage, with one copy off-site or in the cloud.",
                "Install software and phone updates promptly. They often fix security holes that attackers are already using.",
                "Turn on automatic updates for your operating system and apps wherever you can."
            },
            new[]
            {
                "Updates (patches) close known weaknesses. Putting them off leaves a door open that criminals already know how to use.",
                "Test your backups now and then by restoring one file. A backup you can't restore isn't a backup."
            },
            "you could check when your last backup ran.");

        // The general topic is last so that more specific topics win when both match.
        AddTopic("security", "online safety",
            new[] { "security", "cyber", "stay safe", "safe online", "online safety", "hacker", "hacked" },
            new[]
            {
                "Security is crucial. Keep your software up to date and be careful of suspicious links.",
                "Strong unique passwords, 2FA and thinking before you click stop most attacks. Start with those three habits.",
                "Back up your important data regularly and use antivirus software."
            },
            new[]
            {
                "Most attacks target people, not technology. Staying calm and checking unexpected requests is your best defence.",
                "If you think you've been hacked, change your passwords from a clean device, turn on 2FA, and tell your bank if money is involved."
            },
            "you could pick one habit this week, like turning on 2FA, and set it up.");
    }

    private void LoadSentiment()
    {
        sentimentWords["worried"] = new List<string> { "worried", "worry", "scared", "afraid", "anxious", "nervous", "concerned", "terrified", "panic", "unsafe" };
        sentimentWords["frustrated"] = new List<string> { "frustrated", "frustrating", "annoyed", "annoying", "angry", "fed up", "irritated", "sick of" };
        sentimentWords["confused"] = new List<string> { "confused", "confusing", "don't understand", "dont understand", "do not understand", "unsure", "overwhelmed", "not sure", "no idea", "complicated" };
        sentimentWords["curious"] = new List<string> { "curious", "wonder", "fascinated", "want to learn", "would like to learn" };

        sentimentReplies["worried"] = new List<string>
        {
            "It's completely understandable to feel that way, {name}. Attackers can be very convincing, but you are already doing the right thing by asking. Let me share a tip to help you stay safe:",
            "Don't worry, {name} - being careful is a healthy security habit. Here is something practical you can do:"
        };
        sentimentReplies["frustrated"] = new List<string>
        {
            "I hear you, {name} - security can feel like a lot of effort. Let's keep it simple with one easy win:",
            "That's a fair frustration, {name}. Let's take it one small step at a time. Try this:"
        };
        sentimentReplies["confused"] = new List<string>
        {
            "No problem, {name} - this can be confusing and it's fine to ask. Let me explain it more simply:",
            "That's okay, {name}, nobody is born knowing this. Let me break it down:"
        };
        sentimentReplies["curious"] = new List<string>
        {
            "Great to see your curiosity, {name}! Curious users are safer users. Here is something interesting:",
            "Love the curiosity, {name}! Let's dig in:"
        };
    }

    private void LoadSmallTalk()
    {
        smallTalk["how are you"] = new List<string>
        {
            "I'm doing great, {name}, thanks for asking! I'm ready to talk about staying safe online. How are you?",
            "All systems secure and running smoothly, {name}! How are you doing?"
        };
        smallTalk["purpose"] = new List<string>
        {
            "I'm the Cybersecurity Awareness Assistant, {name}. My purpose is to teach you how to spot scams, phishing and other online threats. "
            + "I can give tips, remember what you're interested in, keep a task list with reminders, run a quiz and show an activity log."
        };
        smallTalk["who are you"] = smallTalk["purpose"];
        smallTalk["what can you do"] = smallTalk["purpose"];
        smallTalk["what can i ask"] = new List<string>
        {
            "You can ask me about password safety, phishing, scams, privacy, 2FA, safe browsing, malware, Wi-Fi security, social engineering and backups.\n"
            + "Try: \"Give me a phishing tip\", \"Add a task to enable 2FA\", \"Remind me to update my password tomorrow\", \"Show my tasks\", \"Start the quiz\" or \"What have you done for me?\"."
        };
        smallTalk["help"] = smallTalk["what can i ask"];
        smallTalk["topics"] = smallTalk["what can i ask"];
        smallTalk["hello"] = new List<string> { "Hello {name}! What would you like to learn about today?", "Hi there, {name}! Ask me anything about staying safe online." };
        smallTalk["hi"] = smallTalk["hello"];
        smallTalk["hey"] = smallTalk["hello"];
        smallTalk["howzit"] = smallTalk["hello"];
        smallTalk["good morning"] = smallTalk["hello"];
        smallTalk["thanks"] = new List<string> { "You're welcome, {name}! Stay safe out there. Anything else I can help with?" };
        smallTalk["thank you"] = smallTalk["thanks"];
        smallTalk["bye"] = new List<string> { "Goodbye {name}! Remember: think before you click." };
        smallTalk["goodbye"] = smallTalk["bye"];
    }

    // =====================================================================================
    // Questions the bot asked earlier (name, task title, reminder)
    // =====================================================================================

    private string HandlePendingStep(string raw, string q)
    {
        DateTime when;
        string rest;

        if (pendingStep == "name")
        {
            string name = ExtractName(raw);
            if (name == "") return "I didn't quite catch that. What name should I call you?";

            userName = name;
            pendingStep = "";
            Log.Add("Name remembered: " + name);
            return "Nice to meet you, " + name + "! You can ask me about passwords, phishing, scams, privacy and more. "
                 + "You can also say \"add a task\", \"start the quiz\" or \"show activity log\". What would you like to do?";
        }

        if (pendingStep == "taskTitle")
        {
            pendingStep = "";
            if (NlpHelper.IsNo(q)) return "No problem, I've cancelled that. What else can I help with?";
            return CreateTask(raw, pendingIsReminder);
        }

        if (pendingStep == "reminderChoice")
        {
            if (NlpHelper.TryFindTime(q, out when, out rest)) return SetPendingReminder(when);
            if (NlpHelper.IsNo(q))
            {
                pendingStep = "";
                return "No problem, {name}. The task is saved without a reminder.";
            }
            if (NlpHelper.IsYes(q))
            {
                pendingStep = "reminderTime";
                retries = 0;
                return "When should I remind you? For example: \"in 3 days\", \"tomorrow\", \"next week\" or \"2026-12-01\".";
            }
            pendingStep = "";      // the user said something else, so treat it as a normal message
            return "";
        }

        if (pendingStep == "reminderTime")
        {
            if (NlpHelper.TryFindTime(q, out when, out rest)) return SetPendingReminder(when);
            if (NlpHelper.IsNo(q))
            {
                pendingStep = "";
                return "Okay, I won't set a reminder. The task is still saved.";
            }
            retries++;
            if (retries == 1)
                return "I couldn't read that time. Try \"in 3 days\", \"tomorrow\", \"next week\" or a date like 2026-12-01 (or say \"no\" to skip).";
            pendingStep = "";
            return "";
        }

        return "";
    }

    private string SetPendingReminder(DateTime when)
    {
        pendingStep = "";
        if (pendingTask == null) return "I lost track of which task that was. Please add it again.";

        Tasks.SetReminder(pendingTask, when);
        return "Got it! I'll remind you about '" + pendingTask.Title + "' on " + NlpHelper.DescribeTime(when) + ".";
    }

    /// <summary>Works out a person's name from "my name is Sam", "I'm Sam", "call me Sam" or just "Sam".</summary>
    private string ExtractName(string raw)
    {
        string text = raw.Trim().TrimEnd('.', '!');
        string lower = text.ToLower();
        string[] prefixes = { "my name is ", "my name's ", "i am ", "i'm ", "im ", "call me ", "this is ", "it's " };

        foreach (string prefix in prefixes)
        {
            int position = lower.IndexOf(prefix);
            if (position >= 0)
            {
                text = text.Substring(position + prefix.Length).Trim();
                break;
            }
        }

        // A name is one to three words made of letters only.
        if (!Regex.IsMatch(text, @"^[A-Za-z][A-Za-z'\-]*( [A-Za-z][A-Za-z'\-]*){0,2}$")) return "";
        string[] notNames = { "hello", "hi", "hey", "yes", "no", "ok", "okay", "help", "quiz", "bye", "thanks" };
        if (notNames.Contains(text.ToLower())) return "";

        return char.ToUpper(text[0]) + text.Substring(1);
    }

    // =====================================================================================
    // Step 7 of the guide: capture what the user shares (memory)
    // =====================================================================================

    private string CaptureUserInfo(string raw, string q)
    {
        // Questions about what the bot remembers
        if (Regex.IsMatch(q, @"what do you (remember|know) about me|what'?s my name|what is my name|who am i|do you remember me"))
        {
            string text = userName != "" ? "You told me your name is " + userName + "." : "I don't know your name yet.";
            if (favouriteTopic != "")
                text += " You're interested in " + TopicDisplay(favouriteTopic) + ".";
            else
                text += " Tell me a topic you like, for example \"I'm interested in privacy\".";
            return text;
        }

        // "my name is ..." / "call me ..." during the conversation
        Match nameMatch = Regex.Match(raw, @"\b(?:my name is|call me)\s+([a-z][a-z'\-]+(?: [a-z][a-z'\-]+)?)", RegexOptions.IgnoreCase);
        if (nameMatch.Success)
        {
            string name = nameMatch.Groups[1].Value;
            userName = char.ToUpper(name[0]) + name.Substring(1);
            Log.Add("Name remembered: " + userName);
            return "Nice to meet you, " + userName + "! I'll remember that.";
        }

        // "I'm interested in privacy", "my favourite topic is phishing", "I like passwords"
        string[] patterns =
        {
            @"\b(?:i'm|i am|im)\s+(?:really |very |quite )?(?:interested in|into|curious about)\s+(.+)$",
            @"\bmy favou?rite (?:cyber ?security )?(?:topic|subject) is\s+(.+)$",
            @"\bi\s+(?:like|love|enjoy|care about|want to learn (?:more )?about)\s+(.+)$"
        };

        for (int i = 0; i < patterns.Length; i++)
        {
            Match m = Regex.Match(raw, patterns[i], RegexOptions.IgnoreCase);
            if (!m.Success) continue;

            string subject = m.Groups[1].Value.Trim().TrimEnd('.', '!', '?');
            string topic = FindTopic(subject.ToLower());

            // Only the first two patterns are clearly about interests; "I like..." needs a known topic.
            if (topic == "" && i == 2) return "";

            if (topic == "")
            {
                favouriteTopic = subject;
                Log.Add("Memory stored: interested in " + subject);
                return "Great! I'll remember that you're interested in " + subject + ". I don't have tips on that yet, but I can help with passwords, phishing, scams, privacy and more.";
            }

            favouriteTopic = topic;
            lastTopic = topic;
            Log.Add("Memory stored: interested in " + topicNames[topic]);
            return "Great! I'll remember that you're interested in " + topicNames[topic] + ". It's a crucial part of staying safe online. "
                 + Pick("tip:" + topic, keywordResponses[topic]);
        }

        return "";
    }

    private string TopicDisplay(string topicOrText)
    {
        return topicNames.ContainsKey(topicOrText) ? topicNames[topicOrText] : topicOrText;
    }

    /// <summary>Uses the remembered interest to personalise a reply: "As someone interested in privacy, ..."</summary>
    private string MemoryNudge(string currentTopic)
    {
        if (favouriteTopic == "") return "";

        string favourite = topicNames.ContainsKey(favouriteTopic) ? favouriteTopic : FindTopic(favouriteTopic.ToLower());
        if (favourite == "") return "";

        bool sameTopic = (favourite == currentTopic);
        bool show = sameTopic ? rng.Next(2) == 0 : rng.Next(3) == 0;
        if (!show) return "";

        return "\n\nAs someone interested in " + topicNames[favourite] + ", " + topicNudges[favourite];
    }

    // =====================================================================================
    // Commands: tasks, reminders, quiz, activity log (Part 3)
    // =====================================================================================

    private string HandleCommands(string raw, string q)
    {
        // Activity log
        if (NlpHelper.WantsActivityLog(q))
        {
            logShown = 0;
            return LogPageText();
        }
        if (previousWasLog && NlpHelper.WantsMore(q))
        {
            return LogPageText();
        }

        // Tasks and reminders. The task commands need the database.
        bool taskCommand = NlpHelper.WantsToViewTasks(q) || NlpHelper.WantsReminder(q) || NlpHelper.WantsToAddTask(q)
                           || NlpHelper.WantsToDeleteTask(q) || NlpHelper.WantsToCompleteTask(q);

        if (taskCommand)
        {
            if (!EnsureDatabase())
                return "Sorry {name}, I can't reach the task database right now (" + DatabaseStatus + "). Please start MySQL and try again.";

            if (NlpHelper.WantsToViewTasks(q))
            {
                LogNlp(raw, "view tasks");
                return TaskListText();
            }
            if (NlpHelper.WantsReminder(q))
            {
                LogNlp(raw, "set reminder");
                return CreateTask(NlpHelper.ExtractReminderTitle(raw), true);
            }
            if (NlpHelper.WantsToAddTask(q))
            {
                LogNlp(raw, "add task");
                return CreateTask(NlpHelper.ExtractTaskTitle(raw), false);
            }
            if (NlpHelper.WantsToDeleteTask(q))
            {
                LogNlp(raw, "delete task");
                return ChangeTask(q, false);
            }
            LogNlp(raw, "complete task");
            return ChangeTask(q, true);
        }

        // Quiz
        if (NlpHelper.WantsQuiz(q))
        {
            LogNlp(raw, "start quiz");
            QuizRequested = true;
            return "Great idea, {name}! Opening the Cybersecurity Quiz - answer each question and I'll give you feedback.";
        }

        return "";
    }

    private void LogNlp(string raw, string intent)
    {
        string shortText = raw.Length > 60 ? raw.Substring(0, 57) + "..." : raw;
        Log.Add("NLP: understood \"" + shortText + "\" as '" + intent + "'");
    }

    /// <summary>Creates a task from free text, picking a time phrase out of it if there is one.</summary>
    private string CreateTask(string rawTitle, bool startedWithReminder)
    {
        DateTime when;
        string withoutTime;
        bool hasTime = NlpHelper.TryFindTime(rawTitle, out when, out withoutTime);
        string title = NlpHelper.CleanTitle(withoutTime);

        // No title yet: ask for it
        if (title.Length < 2)
        {
            pendingStep = "taskTitle";
            pendingIsReminder = startedWithReminder;
            return startedWithReminder
                ? "Sure! What should I remind you about?"
                : "Sure! What should the task be? For example: \"Enable two-factor authentication\".";
        }

        string description = NlpHelper.DescribeTask(title);
        DateTime? reminder = null;
        if (hasTime) reminder = when;

        TaskItem task = Tasks.AddTask(title, description, reminder);

        if (hasTime)
        {
            if (startedWithReminder)
                return "Reminder set for '" + title + "' on " + NlpHelper.DescribeTime(when) + ".";
            return "Task added: '" + title + "' with the description \"" + description + "\" I'll remind you on " + NlpHelper.DescribeTime(when) + ".";
        }

        // Task saved without a time: ask the follow-up question
        pendingTask = task;
        retries = 0;
        if (startedWithReminder)
        {
            pendingStep = "reminderTime";
            return "Task added: '" + title + "'. When should I remind you? (for example \"in 3 days\" or \"tomorrow\")";
        }

        pendingStep = "reminderChoice";
        return "Task added: '" + title + "' with the description \"" + description + "\" Would you like a reminder?";
    }

    /// <summary>Marks a task as completed or deletes it. The task is found by number or by words in its title.</summary>
    private string ChangeTask(string q, bool complete)
    {
        List<TaskItem> all = Tasks.GetAllTasks();
        TaskItem found = null;

        Match number = Regex.Match(q, @"\b(\d+)\b");
        int id;
        if (number.Success && int.TryParse(number.Groups[1].Value, out id))
        {
            found = all.FirstOrDefault(t => t.Id == id);
        }
        else
        {
            string words = Regex.Replace(q, @"\b(complete|completed|finish|finished|done|mark|delete|remove|the|a|my|as|task|tasks|please|can|you|could|i|it|to|want)\b", " ");
            words = Regex.Replace(words, @"\s+", " ").Trim();
            if (words.Length >= 3)
                found = all.FirstOrDefault(t => t.Title.ToLower().Contains(words));
        }

        if (found == null)
        {
            if (all.Count == 0) return "You don't have any tasks yet. Say \"add a task\" to create one.";
            string verb = complete ? "complete" : "delete";
            return "I couldn't tell which task to " + verb + ". Use its number, for example \"" + verb + " task " + all[0].Id + "\".\n\n" + TaskListText();
        }

        if (complete)
        {
            if (found.IsCompleted) return "'" + found.Title + "' is already marked as completed.";
            Tasks.MarkCompleted(found);
            return "Well done, {name}! I've marked '" + found.Title + "' as completed.";
        }

        Tasks.DeleteTask(found);
        return "Done - I've deleted the task '" + found.Title + "'.";
    }

    private string TaskListText()
    {
        List<TaskItem> all = Tasks.GetAllTasks();
        if (all.Count == 0)
            return "You have no tasks yet. Say something like \"Add a task to enable 2FA\" and I'll save it for you.";

        StringBuilder sb = new StringBuilder("Here are your cybersecurity tasks:");
        foreach (TaskItem t in all)
        {
            string mark = t.IsCompleted ? "[done]" : "[ ]";
            sb.Append("\n#" + t.Id + " " + mark + " " + t.Title + " - " + t.Description + " (Reminder: " + t.ReminderText + ")");
        }
        return sb.ToString();
    }

    /// <summary>Shows the next 5 log entries, newest first. Saying "show more" shows the next 5.</summary>
    private string LogPageText()
    {
        List<string> page = Log.GetPage(logShown, 5);
        if (page.Count == 0)
        {
            return logShown == 0
                ? "I haven't done anything yet. Try adding a task or starting the quiz!"
                : "That's everything - there are no older actions.";
        }

        StringBuilder sb = new StringBuilder("Here's a summary of recent actions:");
        for (int i = 0; i < page.Count; i++)
        {
            sb.Append("\n" + (logShown + i + 1) + ". " + page[i]);
        }

        logShown += page.Count;
        lastWasLog = true;
        if (logShown < Log.Count) sb.Append("\n\nSay \"show more\" to see older actions.");
        return sb.ToString();
    }

    // =====================================================================================
    // Sentiment, keywords, follow-ups, small talk (Part 2 features)
    // =====================================================================================

    /// <summary>Returns the mood found in the text ("worried", "frustrated", ...) or "" when there is none.</summary>
    private string DetectSentiment(string q)
    {
        foreach (KeyValuePair<string, List<string>> pair in sentimentWords)
        {
            foreach (string word in pair.Value)
            {
                if (NlpHelper.HasWord(q, word)) return pair.Key;
            }
        }
        return "";
    }

    /// <summary>Shows empathy first, then immediately shares a tip so the user doesn't have to ask again.</summary>
    private string HandleSentiment(string q)
    {
        string mood = DetectSentiment(q);
        if (mood == "") return "";

        Log.Add("Sentiment detected: " + mood);
        string empathy = Pick("mood:" + mood, sentimentReplies[mood]);

        string mentioned = FindTopic(q);
        string topic = mentioned;
        if (topic == "") topic = lastTopic;
        if (topic == "" && favouriteTopic != "") topic = topicNames.ContainsKey(favouriteTopic) ? favouriteTopic : FindTopic(favouriteTopic.ToLower());

        if (topic == "" && mood == "confused")
            return "That's okay, {name} - let's start small. Pick a topic and I'll explain it simply: " + TopicList() + ".";
        if (topic == "" && mood == "curious")
            return "Great to see your curiosity, {name}! I can tell you about " + TopicList() + ". What would you like to explore?";

        if (topic == "")
        {
            string[] defaults = { "phishing", "scam", "password", "2fa" };
            topic = defaults[rng.Next(defaults.Length)];
        }
        lastTopic = topic;

        // Confused about the topic we are already discussing: explain it in more detail
        bool explain = (mood == "confused" && mentioned == "");
        string content = explain
            ? Pick("detail:" + topic, topicDetails[topic])
            : Pick("tip:" + topic, keywordResponses[topic]);

        return empathy + "\n\n" + content + MemoryNudge(topic);
    }

    /// <summary>Finds the cybersecurity topic mentioned in the text, or "" when there is none.</summary>
    private string FindTopic(string q)
    {
        foreach (string topic in topicOrder)
        {
            foreach (string keyword in topicKeywords[topic])
            {
                if (NlpHelper.HasKeyword(q, keyword)) return topic;
            }
        }
        return "";
    }

    private string HandleKeyword(string q)
    {
        string topic = FindTopic(q);
        if (topic == "") return "";

        lastTopic = topic;
        Log.Add("Keyword recognised: " + topic + " - shared a tip");

        bool wantsExplanation = NlpHelper.ContainsAny(q, "what is", "what's", "explain", "define", "meaning of", "tell me about");
        string content = wantsExplanation
            ? Pick("detail:" + topic, topicDetails[topic]) + " " + Pick("tip:" + topic, keywordResponses[topic])
            : Pick("tip:" + topic, keywordResponses[topic]);

        return content + MemoryNudge(topic) + "\n\n(Say \"another tip\" or \"tell me more\" to keep going.)";
    }

    /// <summary>Handles "tell me more", "explain" and "give me another tip" using the last topic.</summary>
    private string HandleFollowUp(string q)
    {
        bool wantsDetail = NlpHelper.WantsDetail(q);
        bool wantsAnother = NlpHelper.WantsAnotherTip(q);
        if (!wantsDetail && !wantsAnother) return "";

        if (lastTopic == "")
            return "Happy to go further, {name}! Which topic would you like? I know about " + TopicList() + ".";

        if (wantsDetail)
            return "More on " + topicNames[lastTopic] + ": " + Pick("detail:" + lastTopic, topicDetails[lastTopic]) + MemoryNudge(lastTopic);

        return "Another " + topicNames[lastTopic] + " tip: " + Pick("tip:" + lastTopic, keywordResponses[lastTopic]) + MemoryNudge(lastTopic);
    }

    private string HandleSmallTalk(string q)
    {
        foreach (KeyValuePair<string, List<string>> pair in smallTalk)
        {
            if (NlpHelper.HasWord(q, pair.Key)) return Pick("talk:" + pair.Key, pair.Value);
        }
        return "";
    }

    /// <summary>Used only when nothing else matched. It still points the user towards something useful.</summary>
    private string Fallback()
    {
        if (lastTopic != "")
        {
            return "I'm not sure I understand, {name}. Would you like another " + topicNames[lastTopic]
                 + " tip? Say \"another tip\" or \"tell me more\" - or ask about " + TopicList() + ".";
        }
        return "I didn't quite understand that, {name}. Could you rephrase? You can ask about " + TopicList()
             + ", or say \"add a task\", \"start the quiz\" or \"show activity log\".";
    }

    // =====================================================================================
    // Small helpers
    // =====================================================================================

    private string NameForReply()
    {
        return userName != "" ? userName : "friend";
    }

    private string TopicList()
    {
        return "password safety, phishing, scams, privacy, 2FA, safe browsing, malware, Wi-Fi, social engineering and backups";
    }

    /// <summary>Random item from the list, never the same one twice in a row (so tips feel varied).</summary>
    private string Pick(string key, List<string> items)
    {
        if (items.Count == 1) return items[0];

        int last = lastPicked.ContainsKey(key) ? lastPicked[key] : -1;
        int index;
        do
        {
            index = rng.Next(items.Count);
        } while (index == last);

        lastPicked[key] = index;
        return items[index];
    }
}

