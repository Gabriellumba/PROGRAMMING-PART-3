﻿using System;
using MySqlConnector;

namespace WinFormsApp1.Data
{
    /// <summary>
    /// Database configuration class for MySQL connections
    /// </summary>
    public class DbConfig
    {
        private const string DatabaseName = "cybersecurity_chatbot";

        /// <summary>
        /// Gets the MySQL connection string
        /// </summary>
        public static string GetConnectionString()
        {
            var builder = new MySqlConnectionStringBuilder
            {
                Server = "localhost",
                Port = 3306,
                Database = DatabaseName,
                UserID = "root",
                Password = Environment.GetEnvironmentVariable("CHATBOT_DB_PASSWORD") ?? string.Empty,
                ConnectionTimeout = 5
            };

            return builder.ConnectionString;
        }
    }
}
