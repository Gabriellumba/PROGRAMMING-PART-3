﻿using System;
using MySqlConnector;
using WinFormsApp1.Models;

namespace WinFormsApp1.Data
{
    /// <summary>Reads and writes task records in the cybersecurity chatbot database.</summary>
    public class TaskRepository
    {
        private readonly string connectionString;

        public TaskRepository()
            : this(DbConfig.GetConnectionString())
        {
        }

        public TaskRepository(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new ArgumentException("A database connection string is required.", nameof(connectionString));
            }

            this.connectionString = connectionString;
        }

        /// <summary>Adds a task and returns it with its database-generated ID.</summary>
        public TaskItem AddTask(TaskItem task)
        {
            ArgumentNullException.ThrowIfNull(task);
            ValidateTitle(task.Title);

            using var connection = new MySqlConnection(connectionString);
            connection.Open();

            const string sql = "INSERT INTO tasks (title, description, reminder_date, is_completed) " +
                               "VALUES (@title, @description, @reminder, @completed);";
            using var command = new MySqlCommand(sql, connection);
            command.Parameters.AddWithValue("@title", task.Title.Trim());
            command.Parameters.AddWithValue("@description", task.Description ?? string.Empty);
            command.Parameters.AddWithValue("@reminder", task.ReminderDate.HasValue
                ? task.ReminderDate.Value
                : DBNull.Value);
            command.Parameters.AddWithValue("@completed", task.IsCompleted);
            command.ExecuteNonQuery();

            task.Id = checked((int)command.LastInsertedId);
            return task;
        }

        /// <summary>Returns all tasks ordered by their database ID.</summary>
        public List<TaskItem> GetAllTasks()
        {
            var tasks = new List<TaskItem>();

            using var connection = new MySqlConnection(connectionString);
            connection.Open();

            const string sql = "SELECT id, title, description, reminder_date, is_completed " +
                               "FROM tasks ORDER BY id;";
            using var command = new MySqlCommand(sql, connection);
            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                tasks.Add(new TaskItem
                {
                    Id = reader.GetInt32("id"),
                    Title = reader.GetString("title"),
                    Description = reader.IsDBNull(reader.GetOrdinal("description"))
                        ? string.Empty
                        : reader.GetString("description"),
                    ReminderDate = reader.IsDBNull(reader.GetOrdinal("reminder_date"))
                        ? null
                        : reader.GetDateTime("reminder_date"),
                    IsCompleted = reader.GetBoolean("is_completed")
                });
            }

            return tasks;
        }

        /// <summary>Updates the title, description, reminder, and completion state of a task.</summary>
        public bool UpdateTask(TaskItem task)
        {
            ArgumentNullException.ThrowIfNull(task);
            ValidateTitle(task.Title);

            using var connection = new MySqlConnection(connectionString);
            connection.Open();

            const string sql = "UPDATE tasks SET title = @title, description = @description, " +
                               "reminder_date = @reminder, is_completed = @completed WHERE id = @id;";
            using var command = new MySqlCommand(sql, connection);
            command.Parameters.AddWithValue("@title", task.Title.Trim());
            command.Parameters.AddWithValue("@description", task.Description ?? string.Empty);
            command.Parameters.AddWithValue("@reminder", task.ReminderDate.HasValue
                ? task.ReminderDate.Value
                : DBNull.Value);
            command.Parameters.AddWithValue("@completed", task.IsCompleted);
            command.Parameters.AddWithValue("@id", task.Id);

            return command.ExecuteNonQuery() > 0;
        }

        /// <summary>Sets or clears a task reminder.</summary>
        public bool SetReminder(int taskId, DateTime? reminderDate)
        {
            using var connection = new MySqlConnection(connectionString);
            connection.Open();

            const string sql = "UPDATE tasks SET reminder_date = @reminder WHERE id = @id;";
            using var command = new MySqlCommand(sql, connection);
            command.Parameters.AddWithValue("@reminder", reminderDate.HasValue
                ? reminderDate.Value
                : DBNull.Value);
            command.Parameters.AddWithValue("@id", taskId);

            return command.ExecuteNonQuery() > 0;
        }

        /// <summary>Marks a task as completed.</summary>
        public bool MarkCompleted(int taskId)
        {
            using var connection = new MySqlConnection(connectionString);
            connection.Open();

            using var command = new MySqlCommand(
                "UPDATE tasks SET is_completed = 1 WHERE id = @id;", connection);
            command.Parameters.AddWithValue("@id", taskId);

            return command.ExecuteNonQuery() > 0;
        }

        /// <summary>Deletes a task by ID.</summary>
        public bool DeleteTask(int taskId)
        {
            using var connection = new MySqlConnection(connectionString);
            connection.Open();

            using var command = new MySqlCommand("DELETE FROM tasks WHERE id = @id;", connection);
            command.Parameters.AddWithValue("@id", taskId);

            return command.ExecuteNonQuery() > 0;
        }

        private static void ValidateTitle(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
            {
                throw new ArgumentException("A task title is required.", nameof(title));
            }

            if (title.Trim().Length > 200)
            {
                throw new ArgumentException("A task title cannot exceed 200 characters.", nameof(title));
            }
        }
    }
}
