using Microsoft.VisualBasic;
using System.Media;
using WinFormsApp1.services;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        // ChatbotEngine handles all conversation logic
        private ChatbotEngine _engine;

        // Conversation display management
        private List<(string Sender, string Message)> conversationHistory = 
            new List<(string, string)>();

        private const int MaxVisibleInteractions = 4;

        public Form1()
        {
            InitializeComponent();
            _engine = new ChatbotEngine();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                playgreeting();
                displayLogo();

                // Start the conversation
                string greeting = _engine.StartConversation();
                AddMessageToHistory("Chatbot", greeting);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading form: {ex.Message}");
            }
        }

        /// <summary>
        /// Send button - processes user input through ChatbotEngine
        /// </summary>
        private void button2_Click(object sender, EventArgs e)
        {
            string userInput = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(userInput))
            {
                return;
            }

            try
            {
                // Add user message to display
                AddMessageToHistory("You", userInput);

                // Get response from ChatbotEngine
                string response = _engine.ProcessInput(userInput);

                // Add bot response to display
                AddMessageToHistory("Chatbot", response);

                // Clear input
                textBox1.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error processing message: {ex.Message}");
            }
        }

        /// <summary>
        /// Clear button - resets conversation
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Clear UI
                textBox1.Text = "";
                conversationHistory.Clear();
                label2.Text = "";

                // Reset ChatbotEngine
                _engine.ResetConversation();

                // Restart greeting
                playgreeting();
                string greeting = _engine.StartConversation();
                AddMessageToHistory("Chatbot", greeting);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error clearing conversation: {ex.Message}");
            }
        }

        /// <summary>
        /// Adds a message to conversation history and updates display
        /// </summary>
        private void AddMessageToHistory(string sender, string message)
        {
            conversationHistory.Add((sender, message));

            // Keep only last N interactions
            if (conversationHistory.Count > MaxVisibleInteractions * 2)
            {
                conversationHistory.RemoveRange(0, conversationHistory.Count - (MaxVisibleInteractions * 2));
            }

            UpdateDisplayedMessages();
        }

        /// <summary>
        /// Updates the display with current conversation
        /// </summary>
        private void UpdateDisplayedMessages()
        {
            string displayText = string.Empty;

            foreach (var (sender, message) in conversationHistory)
            {
                if (sender == "You")
                {
                    displayText += AlignRight(message) + Environment.NewLine;
                }
                else
                {
                    displayText += AlignLeft(message) + Environment.NewLine;
                }
                displayText += Environment.NewLine;
            }

            label2.Text = displayText;
        }

        /// <summary>
        /// Right-aligns user messages
        /// </summary>
        private string AlignRight(string message)
        {
            int labelWidth = label2.Width / 8;
            int spacesNeeded = Math.Max(0, labelWidth - message.Length);
            return new string(' ', spacesNeeded) + message;
        }

        /// <summary>
        /// Left-aligns bot messages
        /// </summary>
        private string AlignLeft(string message)
        {
            return message;
        }

        /// <summary>
        /// Plays greeting audio
        /// </summary>
        private void playgreeting()
        {
            try
            {
                SoundPlayer player = new SoundPlayer("voice/Recording.Wav");
                player.PlaySync();
            }
            catch
            {
                // Audio file not found - continue anyway
            }
        }

        /// <summary>
        /// Displays logo image
        /// </summary>
        private void displayLogo()
        {
            try
            {
                pictureBox1.Image = Image.FromFile("images/LOGO EL THE .png");
            }
            catch
            {
                // Image not found - continue anyway
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Optional: could implement auto-send on Enter key here
        }

        private void label2_Click(object sender, EventArgs e)
        {
            // Optional: could implement copy to clipboard here
        }
    }
}

