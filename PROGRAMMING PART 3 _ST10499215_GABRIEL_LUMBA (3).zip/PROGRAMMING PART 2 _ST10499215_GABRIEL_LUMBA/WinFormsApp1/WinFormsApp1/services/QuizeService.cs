﻿using System;
using System.Collections.Generic;

namespace WinFormsApp1.services
{
    public class QuizService
    {
        private readonly List<QuizQuestion> questions = new List<QuizQuestion>
        {
            new QuizQuestion(
                "What should you do with an unexpected email asking you to verify your password?",
                new[] { "Click its link immediately", "Reply with your password", "Open the official website or app directly", "Forward it to friends" },
                2,
                "Do not use links in unexpected messages. Visit the organization through its official website or app."),
            new QuizQuestion(
                "What is the main benefit of two-factor authentication (2FA)?",
                new[] { "It replaces every software update", "It adds another verification step", "It makes passwords public", "It disables account recovery" },
                1,
                "2FA adds a second verification step, making a stolen password less useful to an attacker."),
            new QuizQuestion(
                "Which password practice is safest?",
                new[] { "Reuse one password everywhere", "Use a unique password for each account", "Use your birthday", "Share it with a friend" },
                1,
                "Use a different, strong password for each account. A password manager can help."),
            new QuizQuestion(
                "What should you do if a message pressures you to send money urgently?",
                new[] { "Send it quickly", "Keep it secret", "Verify the request using a trusted contact method", "Share your banking PIN" },
                2,
                "Urgency and secrecy are common scam tactics. Verify requests through a known, trusted channel."),
            new QuizQuestion(
                "Does the padlock icon in a browser prove a website is trustworthy?",
                new[] { "Yes, always", "No; it indicates an encrypted connection, not that the site is legitimate", "Only on social media", "Only when the page loads quickly" },
                1,
                "HTTPS encrypts the connection, but scammers can also use HTTPS. Check the domain and how you reached it."),
            new QuizQuestion(
                "What is a good way to reduce risk on public Wi-Fi?",
                new[] { "Do sensitive banking on any open network", "Turn off device security", "Avoid sensitive activity or use a trusted VPN", "Share files with everyone" },
                2,
                "Avoid sensitive transactions on untrusted networks. A trusted VPN can add protection to your connection."),
            new QuizQuestion(
                "Why should you install software updates?",
                new[] { "They can fix security vulnerabilities", "They make passwords unnecessary", "They prevent all scams", "They share your files" },
                0,
                "Updates often fix security weaknesses that could otherwise be exploited."),
            new QuizQuestion(
                "What is a useful defense against ransomware?",
                new[] { "Regularly tested backups", "Using the same password everywhere", "Opening unknown attachments", "Disabling all updates" },
                0,
                "Keep regular backups and make sure you can restore them. Store at least one backup separately from your device."),
            new QuizQuestion(
                "What should you do with a one-time verification code?",
                new[] { "Share it with anyone who asks", "Post it online", "Keep it private and enter it only in the service you initiated", "Use it as your public username" },
                2,
                "Never share a one-time code with someone who contacts you. Enter it only in the legitimate sign-in or transaction you started."),
            new QuizQuestion(
                "Which is a warning sign of a phishing message?",
                new[] { "A request to act urgently through an unexpected link", "A saved contact name", "A message with a greeting", "A familiar logo by itself" },
                0,
                "Unexpected urgency, suspicious links, and requests for sensitive information are common phishing warning signs.")
        };

        private readonly Random random = new Random();

        public int QuestionCount => questions.Count;

        /// <summary>Returns a shuffled selection of quiz questions without duplicates.</summary>
        public List<QuizQuestion> GetRandomQuestions(int count = 5)
        {
            if (count <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(count), "Question count must be greater than zero.");
            }

            var selection = new List<QuizQuestion>(questions);
            for (int i = selection.Count - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                (selection[i], selection[j]) = (selection[j], selection[i]);
            }

            return selection.GetRange(0, Math.Min(count, selection.Count));
        }

        /// <summary>Returns whether the selected option is the correct answer.</summary>
        public bool IsCorrect(QuizQuestion question, int selectedIndex)
        {
            ArgumentNullException.ThrowIfNull(question);
            return selectedIndex >= 0
                && selectedIndex < question.Options.Count
                && selectedIndex == question.CorrectIndex;
        }

        /// <summary>Returns answer feedback and the explanation for a question.</summary>
        public string GetFeedback(QuizQuestion question, int selectedIndex)
        {
            ArgumentNullException.ThrowIfNull(question);

            string answer = question.Options[question.CorrectIndex];
            string result = IsCorrect(question, selectedIndex)
                ? "Correct! "
                : $"Not quite. The correct answer is: {answer}. ";

            return result + question.Explanation;
        }
    }

    /// <summary>
    /// One quiz question. True/false questions simply have two options ("True", "False").
    /// </summary>
    public class QuizQuestion
    {
        public string Text { get; }
        public List<string> Options { get; }
        public int CorrectIndex { get; }
        public string Explanation { get; }

        public QuizQuestion(string text, string[] options, int correctIndex, string explanation)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                throw new ArgumentException("Question text is required.", nameof(text));
            }

            ArgumentNullException.ThrowIfNull(options);
            if (options.Length < 2 || options.Any(string.IsNullOrWhiteSpace))
            {
                throw new ArgumentException("A question must have at least two non-empty options.", nameof(options));
            }

            if (correctIndex < 0 || correctIndex >= options.Length)
            {
                throw new ArgumentOutOfRangeException(nameof(correctIndex), "Correct answer index must match an option.");
            }

            Text = text.Trim();
            Options = new List<string>(options);
            CorrectIndex = correctIndex;
            Explanation = explanation?.Trim() ?? string.Empty;
        }
    }
}

