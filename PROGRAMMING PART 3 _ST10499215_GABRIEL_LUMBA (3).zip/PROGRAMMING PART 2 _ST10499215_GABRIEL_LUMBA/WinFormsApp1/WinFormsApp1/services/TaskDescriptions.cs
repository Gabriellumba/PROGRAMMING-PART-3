﻿using MySqlConnector;
using MySqlConnector;
using WinFormsApp1.Data;
using WinFormsApp1.Models;

namespace WinFormsApp1.services
{
    /// <summary>
    /// Handles the cybersecurity tasks: every add, view, complete and delete goes to the MySQL database.
    /// It is an ordinary class (no interfaces or extra layers) so the flow is easy to follow and explain.
    /// </summary>
    public class TaskManager
    {
        private const string DatabaseName = "cyberbot_db";

        // The MySQL password is read from an environment variable so it is never saved in GitHub.
        // If your root user has no password, leave the variable unset.
        private readonly string serverConnection;
        private readonly string databaseConnection;
        private readonly ActivityLog log;

        /// <summary>Raised after the task list changes so the Task tab can reload it.</summary>
        public event EventHandler? TasksChanged;

        public TaskManager(ActivityLog activityLog)
        {
            ArgumentNullException.ThrowIfNull(activityLog);
            log = activityLog;

            var connectionBuilder = new MySqlConnectionStringBuilder(DbConfig.GetConnectionString());
            databaseConnection = connectionBuilder.ConnectionString;
            connectionBuilder.Database = string.Empty;
            serverConnection = connectionBuilder.ConnectionString;
        }

        /// <summary>
        /// Creates the database and the tasks table if they do not exist yet.
        /// Returns true when MySQL is ready; otherwise <paramref name="message"/> explains what went wrong.
        /// </summary>
        public bool Initialize(out string message)
        {
            try
            {
                using (MySqlConnection server = new MySqlConnection(serverConnection))
                {
                    server.Open();
                    using (MySqlCommand create = new MySqlCommand("CREATE DATABASE IF NOT EXISTS " + DatabaseName + ";", server))
                    {
                        create.ExecuteNonQuery();
                    }
                }

                using (MySqlConnection conn = new MySqlConnection(databaseConnection))
                {
                    conn.Open();
                    string sql = "CREATE TABLE IF NOT EXISTS tasks ("
                               + "id INT AUTO_INCREMENT PRIMARY KEY, "
                               + "title VARCHAR(200) NOT NULL, "
                               + "description TEXT, "
                               + "reminder_date DATETIME NULL, "
                               + "is_completed TINYINT(1) NOT NULL DEFAULT 0);";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }

                message = "Database connected (MySQL)";
                return true;
            }
            catch (Exception ex)
            {
                message = "Could not connect to MySQL: " + ex.Message;
                return false;
            }
        }

        /// <summary>Saves a new task and returns it (with the id the database gave it).</summary>
        public TaskItem AddTask(string title, string description, DateTime? reminder)
        {
            if (string.IsNullOrWhiteSpace(title))
            {
                throw new ArgumentException("A task title is required.", nameof(title));
            }

            title = title.Trim();
            if (title.Length > 200)
            {
                throw new ArgumentException("A task title cannot exceed 200 characters.", nameof(title));
            }

            TaskItem task = new TaskItem();
            task.Title = title;
            task.Description = description ?? string.Empty;
            task.ReminderDate = reminder;

            using (MySqlConnection conn = new MySqlConnection(databaseConnection))
            {
                conn.Open();
                string sql = "INSERT INTO tasks (title, description, reminder_date, is_completed) VALUES (@title, @description, @reminder, 0);";
                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@description", task.Description);
                    cmd.Parameters.AddWithValue("@reminder", reminder.HasValue ? (object)reminder.Value : DBNull.Value);
                    cmd.ExecuteNonQuery();
                    task.Id = (int)cmd.LastInsertedId;
                }
            }

            if (reminder.HasValue)
                log.Add("Task added: '" + title + "' (reminder set for " + reminder.Value.ToString("yyyy-MM-dd HH:mm") + ")");
            else
                log.Add("Task added: '" + title + "' (no reminder set)");

            RaiseTasksChanged();
            return task;
        }

        /// <summary>Reads every task from the database.</summary>
        public List<TaskItem> GetAllTasks()
        {
            List<TaskItem> tasks = new List<TaskItem>();

            using (MySqlConnection conn = new MySqlConnection(databaseConnection))
            {
                conn.Open();
                string sql = "SELECT id, title, description, reminder_date, is_completed FROM tasks ORDER BY id;";
                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    int idColumn = reader.GetOrdinal("id");
                    int titleColumn = reader.GetOrdinal("title");
                    int descriptionColumn = reader.GetOrdinal("description");
                    int reminderColumn = reader.GetOrdinal("reminder_date");
                    int completedColumn = reader.GetOrdinal("is_completed");

                    while (reader.Read())
                    {
                        TaskItem task = new TaskItem();
                        task.Id = reader.GetInt32(idColumn);
                        task.Title = reader.GetString(titleColumn);
                        task.Description = reader.IsDBNull(descriptionColumn) ? "" : reader.GetString(descriptionColumn);
                        if (!reader.IsDBNull(reminderColumn))
                            task.ReminderDate = reader.GetDateTime(reminderColumn);
                        task.IsCompleted = Convert.ToInt32(reader.GetValue(completedColumn)) == 1;
                        tasks.Add(task);
                    }
                }
            }
            return tasks;
        }

        /// <summary>Adds or changes the reminder of an existing task.</summary>
        public void SetReminder(TaskItem task, DateTime when)
        {
            ArgumentNullException.ThrowIfNull(task);
            using (MySqlConnection conn = new MySqlConnection(databaseConnection))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("UPDATE tasks SET reminder_date = @reminder WHERE id = @id;", conn))
                {
                    cmd.Parameters.AddWithValue("@reminder", when);
                    cmd.Parameters.AddWithValue("@id", task.Id);
                    cmd.ExecuteNonQuery();
                }
            }

            task.ReminderDate = when;
            log.Add("Reminder set: '" + task.Title + "' for " + when.ToString("yyyy-MM-dd HH:mm"));
            RaiseTasksChanged();
        }

        /// <summary>Marks a task as completed in the database.</summary>
        public void MarkCompleted(TaskItem task)
        {
            ArgumentNullException.ThrowIfNull(task);
            using (MySqlConnection conn = new MySqlConnection(databaseConnection))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("UPDATE tasks SET is_completed = 1 WHERE id = @id;", conn))
                {
                    cmd.Parameters.AddWithValue("@id", task.Id);
                    cmd.ExecuteNonQuery();
                }
            }

            task.IsCompleted = true;
            log.Add("Task completed: '" + task.Title + "'");
            RaiseTasksChanged();
        }

        /// <summary>Deletes a task from the database.</summary>
        public void DeleteTask(TaskItem task)
        {
            ArgumentNullException.ThrowIfNull(task);
            using (MySqlConnection conn = new MySqlConnection(databaseConnection))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("DELETE FROM tasks WHERE id = @id;", conn))
                {
                    cmd.Parameters.AddWithValue("@id", task.Id);
                    cmd.ExecuteNonQuery();
                }
            }

            log.Add("Task deleted: '" + task.Title + "'");
            RaiseTasksChanged();
        }

        private void RaiseTasksChanged()
        {
            TasksChanged?.Invoke(this, EventArgs.Empty);
        }
    }

}
