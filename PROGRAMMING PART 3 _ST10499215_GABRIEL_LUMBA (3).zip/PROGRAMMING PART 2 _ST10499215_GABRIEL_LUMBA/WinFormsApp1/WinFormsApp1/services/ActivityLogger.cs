﻿using System;
using System;
using System.Collections.Generic;

namespace WinFormsApp1.services
{
    /// <summary>
    /// Remembers every important thing the chatbot does (tasks, reminders, quiz, NLP).
    /// Entries are added at the end of a list and read back newest-first, one page at a time.
    /// </summary>
    public class ActivityLog
    {
        private readonly List<string> entries = new List<string>();
        private readonly object syncRoot = new object();

        /// <summary>Raised after every new entry so the Activity Log tab can refresh itself.</summary>
        public event EventHandler? Changed;

        /// <summary>How many actions have been logged so far.</summary>
        public int Count
        {
            get
            {
                lock (syncRoot)
                {
                    return entries.Count;
                }
            }
        }

        /// <summary>Adds one action together with the time it happened.</summary>
        public void Add(string description)
        {
            if (string.IsNullOrWhiteSpace(description))
            {
                return;
            }

            string entry = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  -  " + description.Trim();
            lock (syncRoot)
            {
                entries.Add(entry);
            }

            Changed?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>Removes all logged actions.</summary>
        public void Clear()
        {
            bool hadEntries;
            lock (syncRoot)
            {
                hadEntries = entries.Count > 0;
                entries.Clear();
            }

            if (hadEntries)
            {
                Changed?.Invoke(this, EventArgs.Empty);
            }
        }

        /// <summary>
        /// Returns up to <paramref name="take"/> entries, newest first, after skipping <paramref name="skip"/>.
        /// </summary>
        public List<string> GetPage(int skip, int take)
        {
            List<string> page = new List<string>();
            if (skip < 0 || take <= 0)
            {
                return page;
            }

            lock (syncRoot)
            {
                for (int i = entries.Count - 1 - skip; i >= 0 && page.Count < take; i--)
                {
                    page.Add(entries[i]);
                }
            }

            return page;
        }
    }

}
