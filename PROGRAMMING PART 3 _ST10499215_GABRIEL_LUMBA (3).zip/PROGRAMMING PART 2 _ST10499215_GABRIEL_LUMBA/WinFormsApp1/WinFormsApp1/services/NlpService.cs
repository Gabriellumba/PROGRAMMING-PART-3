﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Globalization;
using System.Text.RegularExpressions;

namespace WinFormsApp1.services
{
   
    /// <summary>
    /// Simple "NLP" tools built from string methods and regular expressions.
    /// They let the chatbot understand the same request when it is worded in different ways,
    /// pull a task title out of a sentence, and read time phrases such as "in 3 days" or "tomorrow".
    /// </summary>
    public static class NlpHelper
    {
        // ------------------------------------------------------------------------------------
        // Keyword matching
        // ------------------------------------------------------------------------------------

        /// <summary>True when the text contains the whole word or phrase (so "hi" does not match "phishing").</summary>
        public static bool HasWord(string text, string word)
        {
            return Regex.IsMatch(text, @"\b" + Regex.Escape(word) + @"\b");
        }

        /// <summary>True when a word in the text STARTS with the keyword (so "scam" also matches "scams").</summary>
        public static bool HasKeyword(string text, string keyword)
        {
            return Regex.IsMatch(text, @"\b" + Regex.Escape(keyword));
        }

        /// <summary>True when the text contains at least one of the given words.</summary>
        public static bool ContainsAny(string text, params string[] words)
        {
            foreach (string word in words)
            {
                if (text.Contains(word)) return true;
            }
            return false;
        }

        // ------------------------------------------------------------------------------------
        // Intent detection (the text passed in is already lower case)
        // ------------------------------------------------------------------------------------

        public static bool WantsToViewTasks(string q)
        {
            return ContainsAny(q, "show", "view", "list", "see", "display", "open")
                   && ContainsAny(q, "task", "reminders", "to-do", "todo");
        }

        public static bool WantsReminder(string q)
        {
            return q.Contains("remind");
        }

        public static bool WantsToAddTask(string q)
        {
            return ContainsAny(q, "add", "create", "new", "make", "set up")
                   && ContainsAny(q, "task", "to-do", "todo");
        }

        public static bool WantsToDeleteTask(string q)
        {
            return ContainsAny(q, "delete", "remove") && (q.Contains("task") || Regex.IsMatch(q, @"^(complete|finish|mark|delete|remove)\b.*\d"));
        }

        public static bool WantsToCompleteTask(string q)
        {
            return ContainsAny(q, "complete", "finish", "mark", "done") && (q.Contains("task") || Regex.IsMatch(q, @"^(complete|finish|mark|delete|remove)\b.*\d"));
        }

        public static bool WantsQuiz(string q)
        {
            return ContainsAny(q, "quiz", "mini game", "mini-game", "minigame", "test my knowledge", "test me", "play a game");
        }

        public static bool WantsActivityLog(string q)
        {
            return ContainsAny(q, "activity log", "what have you done", "what did you do", "show log", "show the log",
                               "recent actions", "action history", "summary of actions");
        }

        public static bool WantsMore(string q)
        {
            return ContainsAny(q, "show more", "more actions", "older", "see more") || q.Trim() == "more";
        }

        public static bool WantsDetail(string q)
        {
            return ContainsAny(q, "tell me more", "more detail", "more info", "explain", "elaborate", "go on",
                               "continue", "what do you mean", "clarify", "expand", "go deeper")
                   || q.Trim() == "more";
        }

        public static bool WantsAnotherTip(string q)
        {
            return ContainsAny(q, "another", "one more", "next tip", "different tip", "more tips", "give me more");
        }

        public static bool IsYes(string q)
        {
            string s = q.Trim();
            return s.StartsWith("yes") || s.StartsWith("yeah") || s.StartsWith("yep") || s.StartsWith("sure")
                   || s.StartsWith("ok") || s.StartsWith("please") || s == "y";
        }

        public static bool IsNo(string q)
        {
            string s = q.Trim();
            return s.StartsWith("no") || s.StartsWith("nope") || s.StartsWith("nah") || s.StartsWith("skip")
                   || s.StartsWith("cancel") || s.StartsWith("not now") || s == "n";
        }

        // ------------------------------------------------------------------------------------
        // Pulling information out of a sentence (these use the ORIGINAL text to keep capital letters)
        // ------------------------------------------------------------------------------------

        /// <summary>"Add task - Review privacy settings" gives "Review privacy settings".</summary>
        public static string ExtractTaskTitle(string raw)
        {
            Match m = Regex.Match(raw,
                @"\b(?:task|to-?do)\b[\s:\-\u2013]*(?:(?:to|for|called|named|about|that)\b[\s:\-\u2013]*)?(.+)$",
                RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim() : "";
        }

        /// <summary>"Remind me to update my password tomorrow" gives "update my password tomorrow".</summary>
        public static string ExtractReminderTitle(string raw)
        {
            Match m = Regex.Match(raw,
                @"(?:remind me(?:\s+(?:to|about|of))?|reminders?(?:\s+(?:to|for|about|of))?)\s*[:\-\u2013]?\s*(.+)$",
                RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim() : "";
        }

        /// <summary>Tidies a title: removes filler words, expands "2FA", and starts with a capital letter.</summary>
        public static string CleanTitle(string title)
        {
            string s = title.Trim();
            s = Regex.Replace(s, @"^(?:to|for|about|called|named|that|me to|me)\s+", "", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\s+please$", "", RegexOptions.IgnoreCase);
            s = s.Trim(' ', '.', ',', '!', '?', '-', ':', '"');
            s = Regex.Replace(s, @"\b2fa\b", "two-factor authentication (2FA)", RegexOptions.IgnoreCase);
            if (s.Length == 0) return s;
            return char.ToUpper(s[0]) + s.Substring(1);
        }

        /// <summary>Writes a helpful description for a task by looking for keywords in its title.</summary>
        public static string DescribeTask(string title)
        {
            string t = title.ToLower();
            if (ContainsAny(t, "2fa", "two-factor", "two factor", "authenticat"))
                return "Enable two-factor authentication to add an extra layer of protection to your account.";
            if (t.Contains("privacy"))
                return "Review account privacy settings to ensure your data is protected.";
            if (t.Contains("password"))
                return "Use a strong, unique password or passphrase and keep it in a password manager.";
            if (ContainsAny(t, "backup", "back up"))
                return "Back up your important files so you can recover from ransomware or a lost device.";
            if (ContainsAny(t, "update", "patch"))
                return "Install the latest updates because they fix security holes that attackers use.";
            if (ContainsAny(t, "wifi", "wi-fi", "router"))
                return "Secure your Wi-Fi: change the default password and use WPA2 or WPA3 encryption.";
            if (ContainsAny(t, "phish", "email"))
                return "Practise spotting suspicious emails and report phishing attempts.";
            return "Cybersecurity task: " + title + ".";
        }

        // ------------------------------------------------------------------------------------
        // Time phrases
        // ------------------------------------------------------------------------------------

        /// <summary>
        /// Looks for a time phrase ("in 3 days", "tomorrow", "next week", "2026-12-01") in the text.
        /// When one is found the date is returned and the phrase is removed from <paramref name="remaining"/>.
        /// </summary>
        public static bool TryFindTime(string text, out DateTime when, out string remaining)
        {
            return ReminderParser.TryFindTime(text, out when, out remaining);
        }

        /// <summary>Friendly text such as "Fri, 13 Nov 2026 09:00 (tomorrow)".</summary>
        public static string DescribeTime(DateTime when)
        {
            int days = (when.Date - DateTime.Today).Days;
            string relative;
            if (days < 0) relative = "overdue";
            else if (days == 0) relative = "today";
            else if (days == 1) relative = "tomorrow";
            else relative = "in " + days + " days";

            return when.ToString("ddd, dd MMM yyyy HH:mm", CultureInfo.InvariantCulture) + " (" + relative + ")";
        }

    }

}
