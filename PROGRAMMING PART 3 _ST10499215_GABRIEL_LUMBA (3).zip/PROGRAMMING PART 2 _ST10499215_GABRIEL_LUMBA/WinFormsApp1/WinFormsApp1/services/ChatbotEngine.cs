﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using WinFormsApp1.Models;

namespace WinFormsApp1.services
{
    /// <summary>
    /// Enhanced Cybersecurity Chatbot Engine
    /// 
    /// A sophisticated conversational AI that provides cybersecurity awareness training.
    /// The engine maintains conversation context, user preferences, and conversation history.
    /// 
    /// Design Philosophy:
    /// - Stateful: remembers user name, topics, and conversation context between messages
    /// - Safe: never throws exceptions - all errors become friendly messages
    /// - Ordered: checks happen in a specific sequence (pending tasks -> user info -> commands -> sentiment -> keywords -> follow-ups -> small talk -> fallback)
    /// - Extensible: easy to add new topics, commands, and response types
    /// </summary>
    public class ChatbotEngine
    {
        // ========================================================================
        // CONVERSATION STATE - What the bot remembers between messages
        // ========================================================================

        private string _userName = "";
        private string _favouriteTopic = "";
        private string _lastTopic = "";
        private Random _random = new Random();

        private ConversationContext _context;
        private int _messageCount = 0;

        // ========================================================================
        // KNOWLEDGE BASE - Topics, keywords, responses, and sentiments
        // ========================================================================

        private Dictionary<string, CybersecurityTopic> _topics;
        private Dictionary<string, List<string>> _sentimentResponses;
        private Dictionary<string, List<string>> _smallTalkResponses;
        private List<string> _topicOrder;

        // ========================================================================
        // CONSTANTS
        // ========================================================================

        private const int MaxContextMessages = 10;
        private const int MaxFollowUpAge = 3;

        // ========================================================================
        // PROPERTIES
        // ========================================================================

        public string UserName => _userName;
        public int MessageCount => _messageCount;
        public string LastTopic => _lastTopic;
        public List<ConversationMessage> ConversationHistory => _context.History;

        // ========================================================================
        // INITIALIZATION
        // ========================================================================

        public ChatbotEngine()
        {
            _context = new ConversationContext();
            _topics = new Dictionary<string, CybersecurityTopic>();
            _sentimentResponses = new Dictionary<string, List<string>>();
            _smallTalkResponses = new Dictionary<string, List<string>>();
            _topicOrder = new List<string>();

            InitializeTopics();
            InitializeSentiments();
            InitializeSmallTalk();
        }

        // ========================================================================
        // PUBLIC API - Main conversation interface
        // ========================================================================

        public string StartConversation()
        {
            _context.State = ConversationState.AwaitingName;
            string greeting = "Hello! Welcome to the Cybersecurity Awareness Assistant. I'm here to help you stay safe online. " +
                            "Before we begin, what's your name?";
            _context.AddMessage(new ConversationMessage("Bot", greeting));
            return greeting;
        }

        public string ProcessInput(string userInput)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(userInput))
                {
                    return GetRandomResponse("I'm listening, {name}. Could you please say something?");
                }

                _messageCount++;
                string normalizedInput = NormalizeInput(userInput);
                string lowerInput = normalizedInput.ToLower();

                _context.AddMessage(new ConversationMessage("User", userInput));

                string response = _context.State switch
                {
                    ConversationState.AwaitingName => HandleNameInput(normalizedInput, lowerInput),
                    ConversationState.AwaitingTaskTitle => HandleTaskTitleInput(normalizedInput, lowerInput),
                    ConversationState.AwaitingReminderTime => HandleReminderTimeInput(normalizedInput, lowerInput),
                    ConversationState.Active => HandleActiveConversation(normalizedInput, lowerInput),
                    _ => HandleActiveConversation(normalizedInput, lowerInput)
                };

                _context.AddMessage(new ConversationMessage("Bot", response));
                return ReplacePersonalization(response);
            }
            catch (Exception ex)
            {
                string errorResponse = $"I apologize, {_userName}. Something went wrong: {ex.Message}. Please try again.";
                return errorResponse;
            }
        }

        public void ResetConversation()
        {
            _userName = "";
            _favouriteTopic = "";
            _lastTopic = "";
            _messageCount = 0;
            _context.Clear();
            _context.State = ConversationState.AwaitingName;
        }

        public string GetTopicTip(string topicKey)
        {
            if (!_topics.ContainsKey(topicKey))
                return $"I don't have information about '{topicKey}'.";

            var topic = _topics[topicKey];
            int tipIndex = _random.Next(topic.Tips.Length);
            return topic.Tips[tipIndex];
        }

        public string GetTopicDetail(string topicKey)
        {
            if (!_topics.ContainsKey(topicKey))
                return "I don't have more details about that topic.";

            var topic = _topics[topicKey];
            if (topic.Details.Length == 0)
                return "No additional details available for this topic.";

            int detailIndex = _random.Next(topic.Details.Length);
            return topic.Details[detailIndex];
        }

        // ========================================================================
        // PRIVATE: Input Handlers
        // ========================================================================

        private string HandleNameInput(string raw, string lower)
        {
            string name = ExtractName(raw);
            if (string.IsNullOrEmpty(name) || name.Length < 2)
                return "I didn't quite catch that. What name should I call you?";

            _userName = name;
            _context.State = ConversationState.Active;
            return $"Nice to meet you, {name}! I'm here to teach you about cybersecurity. " +
                   "You can ask me about passwords, phishing, scams, privacy, 2FA and more. What interests you?";
        }

        private string HandleTaskTitleInput(string raw, string lower)
        {
            _context.State = ConversationState.Active;
            return "Task feature requires integration with TaskManager. For now, I can discuss cybersecurity topics. What would you like to know?";
        }

        private string HandleReminderTimeInput(string raw, string lower)
        {
            _context.State = ConversationState.Active;
            return "Ask me about cybersecurity instead!";
        }

        private string HandleActiveConversation(string raw, string lower)
        {
            string response = "";

            response = CheckForTopicRequest(lower);
            if (!string.IsNullOrEmpty(response)) return response;

            response = CheckForFollowUp(lower);
            if (!string.IsNullOrEmpty(response)) return response;

            response = CheckForSentiment(lower);
            if (!string.IsNullOrEmpty(response)) return response;

            response = CheckForSmallTalk(lower);
            if (!string.IsNullOrEmpty(response)) return response;

            response = CheckForKeywords(lower);
            if (!string.IsNullOrEmpty(response)) return response;

            return GetFallbackResponse();
        }

        // ========================================================================
        // PRIVATE: Response Handlers
        // ========================================================================

        private string CheckForTopicRequest(string input)
        {
            if (input.Contains("tell me about ") || input.Contains("explain ") || 
                input.Contains("what is ") || input.Contains("how to "))
            {
                foreach (var topic in _topics.Values)
                {
                    foreach (var keyword in topic.Keywords)
                    {
                        if (input.Contains(keyword))
                        {
                            _lastTopic = topic.Key;
                            _favouriteTopic = topic.Key;
                            return GetRandomTip(topic.Key);
                        }
                    }
                }
            }

            foreach (var topic in _topics.Values)
            {
                if (input.Contains(topic.Key) || input.Contains(topic.DisplayName.ToLower()))
                {
                    _lastTopic = topic.Key;
                    _favouriteTopic = topic.Key;
                    return GetRandomTip(topic.Key);
                }
            }

            return "";
        }

        private string CheckForFollowUp(string input)
        {
            if (!string.IsNullOrEmpty(_lastTopic) && _context.MessagesSinceTopic < MaxFollowUpAge)
            {
                if (input.Contains("more") || input.Contains("tell me more") || 
                    input.Contains("detail") || input.Contains("explain more"))
                {
                    var topic = _topics[_lastTopic];
                    return GetRandomDetail(_lastTopic) ?? $"That's all I have about {topic.DisplayName}. Want to learn about something else?";
                }
            }
            return "";
        }

        private string CheckForSentiment(string input)
        {
            foreach (var sentiment in _sentimentResponses.Keys)
            {
                if (input.Contains(sentiment))
                {
                    var responses = _sentimentResponses[sentiment];
                    return responses[_random.Next(responses.Count)];
                }
            }
            return "";
        }

        private string CheckForSmallTalk(string input)
        {
            foreach (var smallTalkKey in _smallTalkResponses.Keys)
            {
                if (input.Contains(smallTalkKey))
                {
                    var responses = _smallTalkResponses[smallTalkKey];
                    return responses[_random.Next(responses.Count)];
                }
            }
            return "";
        }

        private string CheckForKeywords(string input)
        {
            foreach (var topic in _topics.Values)
            {
                foreach (var keyword in topic.Keywords)
                {
                    if (input.Contains(keyword))
                    {
                        _lastTopic = topic.Key;
                        return GetRandomTip(topic.Key);
                    }
                }
            }
            return "";
        }

        private string GetFallbackResponse()
        {
            var fallbacks = new[]
            {
                "Interesting! I'm not sure how to respond to that, {name}. Could you ask about passwords, phishing, scams, privacy, 2FA, safe browsing, malware or another cybersecurity topic?",
                "That's a good question, {name}! I'm specialized in cybersecurity awareness. How about I share a tip on that? Ask me about any security topic.",
                "I'd love to help with that, {name}, but cybersecurity is my specialty. Want to learn about staying safe online instead?"
            };

            return fallbacks[_random.Next(fallbacks.Length)];
        }

        // ========================================================================
        // PRIVATE: Knowledge Base Initialization
        // ========================================================================

        private void InitializeTopics()
        {
            AddTopic("2fa", "Two-Factor Authentication",
                new[] { "2fa", "two-factor", "mfa", "authenticator", "otp" },
                new[]
                {
                    "Enable two-factor authentication (2FA) on your important accounts. It requires both your password AND something you have (like your phone).",
                    "Use an authenticator app instead of SMS codes when possible. SMS can be intercepted.",
                    "Save your backup codes somewhere safe, but NOT in email."
                },
                new[]
                {
                    "2FA makes your accounts much harder to hack, even if your password is stolen.",
                    "Many authenticator apps work offline, so they're faster and more secure than SMS."
                });

            AddTopic("password", "Password Safety",
                new[] { "password", "passphrase", "passcode", "credentials" },
                new[]
                {
                    "Use strong, unique passwords for each account. A passphrase like 'purple-tractor-melon-cloud' is both long and memorable.",
                    "Never use personal information like your birthday or pet's name in passwords.",
                    "A password manager can securely store all your passwords - you only need to remember one master password."
                },
                new[]
                {
                    "Length beats complexity - a long password is harder to crack than a short one with symbols.",
                    "If you use the same password everywhere, one breach compromises all your accounts."
                });

            AddTopic("phishing", "Phishing Attacks",
                new[] { "phishing", "phish", "smishing", "fake email", "suspicious email" },
                new[]
                {
                    "Check the sender's email address carefully. Criminals often use similar-looking addresses.",
                    "Never click links in unexpected emails. Instead, go directly to the website or call the organization.",
                    "Be suspicious of urgent messages like 'Your account will be closed in 24 hours!' - that's a classic phishing tactic.",
                    "Hover over links to see where they actually go before clicking."
                },
                new[]
                {
                    "Phishing isn't just email - it also comes via SMS (smishing) and phone calls (vishing).",
                    "Real organizations will never ask for passwords or PINs via email."
                });

            AddTopic("scam", "Online Scams",
                new[] { "scam", "fraud", "con", "too good to be true" },
                new[]
                {
                    "If an offer sounds too good to be true, it probably is. Never pay a fee to receive a prize.",
                    "Never send money or gift cards to someone you only know online.",
                    "Be wary of WhatsApp messages from 'family' asking for urgent money - call their old number first.",
                    "Report scams to your bank and local authorities immediately."
                },
                new[]
                {
                    "Scammers create pressure - urgency, secrecy, or fear. Real organizations give you time to think.",
                    "Common scams: fake job offers, online shopping fraud, romance scams, investment schemes."
                });

            AddTopic("privacy", "Privacy Protection",
                new[] { "privacy", "personal data", "personal information", "tracking" },
                new[]
                {
                    "Limit what you share online. Your ID number, address, and birthday are valuable to criminals.",
                    "Review your social media privacy settings and control who can see your posts.",
                    "Check app permissions - disable location, microphone, and contact access if not needed.",
                    "Use different email addresses for important accounts vs. newsletters."
                },
                new[]
                {
                    "Small details add up - combining your school, birthday, and pet's name reveals answers to security questions.",
                    "POPIA (Protection of Personal Information Act) gives you rights over your data in South Africa."
                });

            AddTopic("browsing", "Safe Browsing",
                new[] { "browsing", "browser", "https", "website", "download", "url" },
                new[]
                {
                    "Look for https:// and a padlock icon before entering personal details.",
                    "Type your bank's address directly instead of clicking links.",
                    "Download apps only from official stores or the maker's website.",
                    "Keep your browser and extensions updated."
                },
                new[]
                {
                    "The padlock means the connection is encrypted, but doesn't guarantee the site is legitimate.",
                    "Shortened links hide their destination - don't click them from untrusted sources."
                });

            AddTopic("malware", "Malware & Viruses",
                new[] { "malware", "virus", "ransomware", "trojan", "spyware" },
                new[]
                {
                    "Use reputable antivirus software and keep it updated.",
                    "Don't open email attachments from unknown senders.",
                    "Avoid clicking on pop-ups claiming your device is infected.",
                    "Back up your important files regularly to protect against ransomware."
                },
                new[]
                {
                    "Ransomware encrypts your files and demands payment. Regular backups are your best defense.",
                    "Malware can steal passwords, banking information, or use your computer for attacks."
                });

            AddTopic("wifi", "Wi-Fi Security",
                new[] { "wifi", "wi-fi", "wireless", "network", "hotspot" },
                new[]
                {
                    "Use a strong password for your home Wi-Fi network.",
                    "Avoid using public Wi-Fi for sensitive transactions like banking.",
                    "Use a VPN on public Wi-Fi to encrypt your data.",
                    "Turn off file sharing and automatic connections."
                },
                new[]
                {
                    "Public Wi-Fi networks are not encrypted - anyone can intercept your data.",
                    "A VPN (Virtual Private Network) encrypts all your internet traffic."
                });

            AddTopic("backup", "Data Backups",
                new[] { "backup", "back up", "restore", "recovery" },
                new[]
                {
                    "Back up your important files regularly to a separate device or cloud storage.",
                    "Test your backups by restoring a file to make sure they work.",
                    "Keep at least one backup offline to protect against ransomware.",
                    "Use the 3-2-1 rule: 3 copies of data, on 2 different media types, 1 offsite."
                },
                new[]
                {
                    "Ransomware is your biggest backup concern - backups protect you when files are encrypted.",
                    "Automatic backups are better than manual ones since you'll actually use them."
                });
        }

        private void InitializeSentiments()
        {
            _sentimentResponses["worried"] = new List<string>
            {
                "I understand, {name}. Cybersecurity can seem overwhelming, but most threats are preventable with good habits.",
                "That's a valid concern, {name}. Let me help you feel more secure."
            };

            _sentimentResponses["excited"] = new List<string>
            {
                "I love the enthusiasm, {name}! Cybersecurity is important and interesting.",
                "Great attitude, {name}! Let's dive deeper."
            };

            _sentimentResponses["confused"] = new List<string>
            {
                "No worries, {name}! Cybersecurity has a lot of jargon. Let me explain it more simply.",
                "Don't worry, {name}, I'll break this down for you."
            };

            _sentimentResponses["scared"] = new List<string>
            {
                "It's natural to feel concerned, {name}. The good news: most cyberattacks are preventable.",
                "Fear is actually smart, {name}. It means you're taking security seriously."
            };
        }

        private void InitializeSmallTalk()
        {
            _smallTalkResponses["how are you"] = new List<string>
            {
                "I'm running smoothly, {name}! Ready to help you stay safe online.",
                "All systems secure, {name}! How are you doing?"
            };

            _smallTalkResponses["hello"] = new List<string>
            {
                "Hello {name}! What would you like to learn about today?",
                "Hi {name}! Ready to level up your cybersecurity knowledge?"
            };

            _smallTalkResponses["hi"] = _smallTalkResponses["hello"];
            _smallTalkResponses["hey"] = _smallTalkResponses["hello"];

            _smallTalkResponses["thanks"] = new List<string>
            {
                "You're welcome, {name}! Stay safe out there.",
                "Happy to help, {name}! Any other questions?"
            };

            _smallTalkResponses["thank you"] = _smallTalkResponses["thanks"];

            _smallTalkResponses["bye"] = new List<string>
            {
                "Goodbye, {name}! Remember to think before you click.",
                "See you later, {name}! Stay cybersecure!"
            };

            _smallTalkResponses["goodbye"] = _smallTalkResponses["bye"];
        }

        private void AddTopic(string key, string displayName, string[] keywords, string[] tips, string[] details)
        {
            _topicOrder.Add(key);
            _topics[key] = new CybersecurityTopic
            {
                Key = key,
                DisplayName = displayName,
                Keywords = keywords.ToList(),
                Tips = tips,
                Details = details
            };
        }

        // ========================================================================
        // PRIVATE: Utility Methods
        // ========================================================================

        private string NormalizeInput(string input)
        {
            input = input.Replace("\u2019", "'");
            return input.Trim();
        }

        private string ExtractName(string input)
        {
            var prefixes = new[] { "i'm ", "i am ", "my name is ", "call me ", "im ", "am " };
            string lower = input.ToLower();

            foreach (var prefix in prefixes)
            {
                if (lower.Contains(prefix))
                {
                    int startIndex = lower.IndexOf(prefix) + prefix.Length;
                    string name = input.Substring(startIndex).Trim();
                    name = name.TrimEnd('.', ',', '!', '?', ';');

                    if (!string.IsNullOrEmpty(name) && name.Length > 1 && name.Length < 50)
                        return name;
                }
            }

            if (input.Length > 1 && input.Length < 50 && !input.Any(char.IsDigit))
                return input;

            return "";
        }

        private string GetRandomTip(string topicKey)
        {
            if (!_topics.ContainsKey(topicKey))
                return GetFallbackResponse();

            var topic = _topics[topicKey];
            int index = _random.Next(topic.Tips.Length);
            _lastTopic = topicKey;
            _context.MessagesSinceTopic = 0;
            return topic.Tips[index];
        }

        private string GetRandomDetail(string topicKey)
        {
            if (!_topics.ContainsKey(topicKey))
                return null;

            var topic = _topics[topicKey];
            if (topic.Details.Length == 0)
                return null;

            int index = _random.Next(topic.Details.Length);
            return topic.Details[index];
        }

        private string GetRandomResponse(string responseTemplate)
        {
            return ReplacePersonalization(responseTemplate);
        }

        private string ReplacePersonalization(string text)
        {
            return text.Replace("{name}", string.IsNullOrEmpty(_userName) ? "friend" : _userName);
        }

        // ========================================================================
        // INNER CLASSES - Supporting data structures
        // ========================================================================

        private class CybersecurityTopic
        {
            public string Key { get; set; }
            public string DisplayName { get; set; }
            public List<string> Keywords { get; set; } = new List<string>();
            public string[] Tips { get; set; } = Array.Empty<string>();
            public string[] Details { get; set; } = Array.Empty<string>();
        }

        private class ConversationContext
        {
            public ConversationState State { get; set; } = ConversationState.AwaitingName;
            public List<ConversationMessage> History { get; set; } = new List<ConversationMessage>();
            public int MessagesSinceTopic { get; set; } = 0;

            public void AddMessage(ConversationMessage message)
            {
                History.Add(message);
                if (message.Sender == "User")
                    MessagesSinceTopic++;

                if (History.Count > MaxContextMessages)
                    History.RemoveAt(0);
            }

            public void Clear()
            {
                History.Clear();
                State = ConversationState.AwaitingName;
                MessagesSinceTopic = 0;
            }
        }

        public enum ConversationState
        {
            AwaitingName,
            Active,
            AwaitingTaskTitle,
            AwaitingReminderTime
        }
    }

    public class ConversationMessage
    {
        public string Sender { get; set; }
        public string Text { get; set; }
        public DateTime Timestamp { get; set; }

        public ConversationMessage(string sender, string text)
        {
            Sender = sender;
            Text = text;
            Timestamp = DateTime.Now;
        }
    }
}
