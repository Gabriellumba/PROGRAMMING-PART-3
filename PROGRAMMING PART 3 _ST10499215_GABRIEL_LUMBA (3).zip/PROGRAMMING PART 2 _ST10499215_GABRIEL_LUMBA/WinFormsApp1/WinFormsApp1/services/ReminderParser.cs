﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace WinFormsApp1.services
{
    /// <summary>Parses common reminder time expressions from user messages.</summary>
    public static class ReminderParser
    {
        private static readonly string[] DateFormats = { "yyyy-MM-dd", "d/M/yyyy", "dd/MM/yyyy" };

        /// <summary>
        /// Finds a supported time expression and removes it from the input text.
        /// Examples include "in 3 days", "tomorrow", "next week", and "25/12/2026".
        /// </summary>
        public static bool TryFindTime(string? text, out DateTime when, out string remaining)
        {
            when = default;
            remaining = text ?? string.Empty;
            if (string.IsNullOrWhiteSpace(text))
            {
                return false;
            }

            DateTime now = DateTime.Now;
            Match relative = Regex.Match(text,
                @"\b(?:in|after)\s+(\d+|an?|one|two|three|four|five|six|seven|eight|nine|ten)\s*(minute|min|hour|hr|day|week|month)s?\b",
                RegexOptions.IgnoreCase);
            if (relative.Success)
            {
                int amount = ParseAmount(relative.Groups[1].Value);
                if (amount <= 0)
                {
                    return false;
                }

                string unit = relative.Groups[2].Value.ToLowerInvariant();
                try
                {
                    when = unit.StartsWith("min") ? now.AddMinutes(amount)
                        : unit.StartsWith("h") ? now.AddHours(amount)
                        : unit == "day" ? now.AddDays(amount)
                        : unit == "week" ? now.AddDays(checked(7 * amount))
                        : now.AddMonths(amount);
                }
                catch (ArgumentOutOfRangeException)
                {
                    return false;
                }
                catch (OverflowException)
                {
                    return false;
                }

                remaining = RemoveMatch(text, relative);
                return true;
            }

            Match named = Regex.Match(text,
                @"(?:\b(?:by|for|on)\s+)?\b(day after tomorrow|tomorrow|tonight|today|next week|next month)\b",
                RegexOptions.IgnoreCase);
            if (named.Success)
            {
                string phrase = named.Groups[1].Value.ToLowerInvariant();
                when = phrase switch
                {
                    "day after tomorrow" => now.Date.AddDays(2).AddHours(9),
                    "tomorrow" => now.Date.AddDays(1).AddHours(9),
                    "tonight" => now.Hour < 20 ? now.Date.AddHours(20) : now.AddHours(1),
                    "today" => now.AddHours(2),
                    "next week" => now.Date.AddDays(7).AddHours(9),
                    _ => now.Date.AddMonths(1).AddHours(9)
                };

                remaining = RemoveMatch(text, named);
                return true;
            }

            Match date = Regex.Match(text,
                @"(?:\b(?:by|for|on)\s+)?(\b\d{4}-\d{2}-\d{2}\b|\b\d{1,2}/\d{1,2}/\d{4}\b)");
            if (date.Success && DateTime.TryParseExact(
                    date.Groups[1].Value,
                    DateFormats,
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out DateTime parsed))
            {
                when = parsed.Date.AddHours(9);
                remaining = RemoveMatch(text, date);
                return true;
            }

            return false;
        }

        private static int ParseAmount(string value)
        {
            if (int.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out int amount))
            {
                return amount;
            }

            return value.ToLowerInvariant() switch
            {
                "two" => 2,
                "three" => 3,
                "four" => 4,
                "five" => 5,
                "six" => 6,
                "seven" => 7,
                "eight" => 8,
                "nine" => 9,
                "ten" => 10,
                _ => 1
            };
        }

        private static string RemoveMatch(string text, Match match)
        {
            string result = text.Remove(match.Index, match.Length);
            result = Regex.Replace(result, @"\s+", " ");
            return result.Trim(' ', ',', '.', '-');
        }
    }
}
