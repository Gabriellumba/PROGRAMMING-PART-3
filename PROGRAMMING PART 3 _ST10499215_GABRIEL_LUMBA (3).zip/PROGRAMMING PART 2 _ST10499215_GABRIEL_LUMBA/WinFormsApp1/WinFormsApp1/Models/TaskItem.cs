﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Models
{
    /// <summary>
    /// One cybersecurity task. This is a plain data class that matches one row of the "tasks" table.
    /// </summary>
    public class TaskItem
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public DateTime? ReminderDate { get; set; }      // null = no reminder
        public bool IsCompleted { get; set; }

        /// <summary>Reminder as text for the screen ("None" when there is no reminder).</summary>
        public string ReminderText
        {
            get { return ReminderDate.HasValue ? ReminderDate.Value.ToString("yyyy-MM-dd HH:mm") : "None"; }
        }

        /// <summary>Status as text for the screen.</summary>
        public string StatusText
        {
            get { return IsCompleted ? "Completed" : "Pending"; }
        }
    }

}
